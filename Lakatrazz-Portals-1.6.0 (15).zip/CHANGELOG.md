**v1.6.0**
- Fixed head offset not applying in certain levels
- Added volumetrics to portal cameras

**v1.5.0**
- Fixed Fusion sync being broken

**v1.4.0**
- Potentially fixed random access violation crashes
- Fixed field injection crashes

**v1.3.0**
- Fixed Quest crashing without Fusion installed
- Added toggle to disable while in Fusion

**v1.2.0**
- Improved IL2CPP memory crashes

**v1.1.0**
- Fixed broken momentum conservation for objects

**v1.0.0**
- Initial release